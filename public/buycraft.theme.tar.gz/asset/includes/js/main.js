$(".modal").draggable({
	handle: ".modal-header"
});