<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <a href="#" class="btn btn-dark">Language</a>
      </div>
      <div class="col-sm-12 col-md-6">
        <p class="minepos-link float-md-right">Powered by <a href="https://minepos.net">MinePoS</a>.</p>
      </div>
    </div>
  </div>
</div>